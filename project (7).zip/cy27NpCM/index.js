function calculatevalue() {

let input1El = document.getElementById("input1").value
let input2El = document.getElementById("input2").value
let answer = document.getElementById("value")
let calVal

if (document.getElementById('radio/').checked)
calVal = parseInt(input1El) / parseInt(input2El);
console.log(calVal)

if (document.getElementById('radio*').checked)
calVal = parseInt(input1El) * parseInt(input2El);
console.log(calVal)

if (document.getElementById('radio-').checked)
calVal = parseInt(input1El) - parseInt(input2El);
console.log(calVal)

if (document.getElementById('radio+').checked)
calVal = parseInt(input1El) + parseInt(input2El);
console.log(calVal)
answer.innerText = calVal
}